#Student name: Zhefu Peng
#Student Penn ID: 29419150

import random
import unittest
from three_musketeers import *

left = 'left'
right = 'right'
up = 'up'
down = 'down'
M = 'M'
R = 'R'
_ = '-'

class TestThreeMusketeers(unittest.TestCase):

    def setUp(self):
        set_board([ [_, _, _, M, _],
                    [_, _, R, M, _],
                    [_, R, M, R, _],
                    [_, R, _, _, _],
                    [_, _, _, R, _] ])

    def test_create_board(self):
        create_board()
        self.assertEqual(at((0, 0)), 'R')
        self.assertEqual(at((0, 4)), 'M')

    def test_set_board(self):
        self.assertEqual(at((0, 0)), '-')
        self.assertEqual(at((1, 2)), 'R')
        self.assertEqual(at((1, 3)), 'M')

    def test_get_board(self):
        self.assertEqual([ [_, _, _, M, _],
                           [_, _, R, M, _],
                           [_, R, M, R, _],
                           [_, R, _, _, _],
                           [_, _, _, R, _] ],
                         get_board())
        

    def test_string_to_location(self):
        #self.fail() # Replace with tests
        self.assertEqual(string_to_location('A5'),(0, 4))
        self.assertEqual(string_to_location('E1'),(4, 0))
        self.assertEqual(string_to_location('C2'),(2, 1))
        

    def test_location_to_string(self):
        #self.fail() # Replace with tests
        self.assertEqual(location_to_string((0,4)),'A5')
        self.assertEqual(location_to_string((4,0)),'E1')
        

    def test_at(self):
        #self.fail() # Replace with tests
        self.assertEqual(at((0,4)),'-')
        self.assertEqual(at((2,2)),'M')
        self.assertEqual(at((1,2)),'R')

    def test_all_locations(self):
        #self.fail() # Replace with tests
        self.assertEqual(all_locations()[3], (0, 3))
        self.assertEqual(all_locations()[10], (2, 0))
        self.assertEqual(all_locations()[22], (4, 2))
        

    def test_adjacent_location(self):
        #self.fail() # Replace with tests
        set_board([ [_, _, _, M, _],
                    [_, R, _, M, _],
                    [_, _, M, _, R],
                    [_, R, _, _, _],
                    [_, _, _, R, _] ] )
        self.assertEqual(adjacent_location((0,4),'left'),(0,3))
        self.assertEqual(adjacent_location((1,4),'up'),(0,4))
        self.assertEqual(adjacent_location((3,4),'down'),(4,4))
        self.assertEqual(adjacent_location((2,2),'right'),(2,3))
        
        
    def test_is_legal_move_by_musketeer(self):
        #self.fail() # Replace with tests
        set_board([ [_, _, _, M, _],
                    [_, R, M, _, _],
                    [_, _, M, _, R],
                    [_, R, _, _, _],
                    [_, _, _, R, _] ] )
        self.assertEqual(is_legal_move_by_musketeer((2,2),'left'),False)
        self.assertEqual(is_legal_move_by_musketeer((1,2),'left'),True)
        self.assertEqual(is_legal_move_by_musketeer((0,3),'right'),False)
        
    def test_is_legal_move_by_enemy(self):
        #self.fail() # Replace with tests
        set_board([ [_, _, _, M, _],
                    [_, R, M, _, _],
                    [_, _, M, _, R],
                    [_, R, _, _, _],
                    [_, _, _, R, _] ] )
        self.assertEqual(is_legal_move_by_enemy((1,1),'left'),True)
        self.assertEqual(is_legal_move_by_enemy((1,1),'right'),False)
        self.assertEqual(is_legal_move_by_enemy((4,3),'down'),False)

    def test_is_legal_move(self):
        #self.fail() # Replace with tests
        set_board([ [_, M, _, _, _],
                    [_, R, _, M, _],
                    [_, _, M, _, R],
                    [_, R, _, _, _],
                    [_, _, _, R, _] ] )
        self.assertEqual(is_legal_move((1,3),'left'),False) #point M
        self.assertEqual(is_legal_move((2,4),'right'),False) #point R
        self.assertEqual(is_legal_move((0,1),'down'),True) #point M
        

        
    def test_has_some_legal_move_somewhere(self):
        set_board([ [_, _, _, M, _],
                    [_, R, _, M, _],
                    [_, _, M, _, R],
                    [_, R, _, _, _],
                    [_, _, _, R, _] ] )
        self.assertFalse(has_some_legal_move_somewhere('M'))
        self.assertTrue(has_some_legal_move_somewhere('R'))
        #self.fail() # Put additional tests here
        set_board([ [_, _, _, M, _],
                    [_, R, M, _, _],
                    [_, _, M, _, R],
                    [_, R, _, _, _],
                    [_, _, _, R, _] ] )
        self.assertTrue(has_some_legal_move_somewhere('M'))
        self.assertTrue(has_some_legal_move_somewhere('R'))

    def test_possible_moves_from(self):
        #self.fail() # Replace with tests
        set_board([ [_, _, _, M, _],
                    [_, _, R, M, _],
                    [_, R, M, R, _],
                    [_, R, _, _, _],
                    [_, _, _, R, _] ])
        self.assertEqual(possible_moves_from((0,3)),[]) 
        self.assertEqual(possible_moves_from((1,3)),['left', 'down'])
        self.assertEqual(possible_moves_from((2,1)),['left', 'up'])
        self.assertEqual(possible_moves_from((2,2)),['left','right', 'up'])


    def test_can_move_piece_at(self):
        set_board([ [_, _, _, M, R],
                    [_, _, _, M, M],
                    [_, _, R, _, _],
                    [_, _, _, _, _],
                    [_, _, _, _, _] ] )
        #self.fail() # Replace with tests
        self.assertFalse(can_move_piece_at((0,4)))
        self.assertFalse(can_move_piece_at((1,3)))
        self.assertTrue(can_move_piece_at((0,3)))



        

    def test_is_legal_location(self):
        #self.fail() # Replace with tests
        self.assertEqual(is_legal_location((0,4)),True)

    def test_is_within_board(self):
        #self.fail() # Replace with tests
        self.assertEqual(is_within_board((1,2),'left'),True)
        self.assertEqual(is_within_board((0,4),'right'),False)
        self.assertEqual(is_within_board((0,4),'up'),False)


        

    def test_all_possible_moves_for(self):
        set_board([ [_, _, R, M, R],
                    [_, _, _, M, M],
                    [_, _, _, _, _],
                    [_, _, _, _, _],
                    [_, _, _, _, _] ] )
        #self.fail() # Replace with tests
        self.assertEqual(all_possible_moves_for('R'), [((0, 2), 'left'), ((0, 2), 'down')])
        self.assertEqual(all_possible_moves_for('M'), [((0, 3), 'left'), ((0, 3), 'right'), ((1, 4), 'up')])
    

    def test_is_enemy_win(self):
        #self.fail() # Replace with tests
        set_board([ [_, _, M, M, M],
                    [_, _, _, _, _],
                    [_, R, _, R, _],
                    [_, R, _, _, _],
                    [_, _, _, R, _] ] )
        self.assertTrue(is_enemy_win())
      
    def test_make_move(self):
        self.assertEqual([ [_, _, _, M, _],
                           [_, _, M, _, _],
                           [_, R, M, R, _],
                           [_, R, _, _, _],
                           [_, _, _, R, _] ],
                         make_move((1, 3), left))
        #self.fail() # Replace with tests

    def test_choose_computer_move(self):
        #self.fail() # Replace with tests; should work for both 'M' and 'R'
        set_board([ [_, _, R, M, R],
                    [_, _, _, M, M],
                    [_, _, _, _, _],
                    [_, _, _, _, _],
                    [_, _, _, _, _] ] )
        self.assertEqual(choose_computer_move('R'), ((0, 2), 'left'))
        self.assertEqual(choose_computer_move('M'), ((0, 3), 'left'))
        
unittest.main()
