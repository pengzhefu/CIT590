a = []
for i in range(0,3):
    for j in range(0,3):
        a.append((i,j))
print(a)

print(a[0])
print(a[0][0])

