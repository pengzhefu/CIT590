'''
Student name: Zhefu Peng
Student Penn ID: 29419150

'''

import random

def instructions():
    print("===============GAME INSTUCTION==================")
    print("Here is the game instruction. I will tell you how to play.")
    print("If you roll six, you will end your turn.",end = " " )
    print("If you roll other numbers, you can continue your turn.")
    print("If you arrive at 50 points earlier than computer, you win.",end = " ")
    print("Otherwise you will lose the game.")
    print("=====================OVER=======================")

def computer_move(computer_score,human_score):
    print("Now its computer's turn.")
    computer = True
    #Using character 'b' to record the score of computer in every turn.
    b = 0
    print("Now the computer scores",computer_score)
    while computer:
        d = computer_score +b - human_score
        if d >= 0:
            print("Now the computer is leading for",d)
            #Using p as a probability to let computer decide whether roll or not.
            #When computer is not behind, the probability to roll is 50%.
            p = random.randint(1,10)
            #If computer roll a number which is larger than 5, he will roll.
        else:
            print("Now the computer is behind by",-d)
            #When computer is behind, the probability to roll is nearly 71.4%.
            p = random.randint(4,10)
            #If computer roll a number which is larger than 5, he will roll.
        if p > 5:
            move = True
            #Show the reason that computer decided to roll or not.
            print("The computer got",p,"so he decides to roll")
        else:
            move = False
            computer = False
            print("The computer decided not to roll because he got",p)
            print("So the computer's turn end and it's your turn.")
        while move:
            #Using character 'y' to record the score of computer in every time.
            y = roll()
            print('The computer got',y,'in this time rolling.')
            if y != 6:
                b = b + y
                print("the computer got",b,"in this turn")
                move = False
                computer = True
                y = 0

            else:
                print("Computer got six!His ending!")
                b = 0
                move = False
                computer = False
                y = 0
            
    return b
            
def human_move(computer_score,human_score):
    print("Now the computer score",computer_score,"Now you score",human_score)
    if computer_score == human_score:
        print("Now you guys are tied!")
        print("Now it's your turn.")
    elif computer_score > human_score:
        print("Now you are behind",(computer_score - human_score),"points")
    else:
        print("Now you are leding",(human_score - computer_score),"points")
    #Using character 'x' to record the score of computer in every turn.
    x = 0
    rolling = True
    while rolling:
        #Using character 'a' to record the score of user in every time.
        a = roll()
        if a != 6:
                x = x + a
                print("you just got",a)
                print("Now your score in this turn is",x)
                
        else:
            print("You got six!")
            x = 0;
            break
        
        rolling = ask_yes_or_no("Will you roll again?(y/n)")   
    print("Your score in this turn is",x)
    return x

def roll():
    how_much = random.randint(1,6)
    return how_much        

def is_game_over(computer_score,human_score):
    #Decide whether the game should end or continue
    if human_score == computer_score:
        game_over = False
        print("Game will be continued")
    elif human_score >= 50 or computer_score >= 50:
        game_over = True
        print("Game is over.")
        print("######################")
    else:
        game_over = False
        print("Game will be continued.")
        #print some character to help players play more easily and clearly
        #making some cut to show process more clearly
        print("*********************")
    return game_over
        
              

def ask_yes_or_no(prompt):
    while True:
        result = input(prompt)
        if result[0] == 'y' or result[0] == 'Y':
            rolling = True
            break
        elif result[0] == 'n' or result[0] == 'N':
            rolling = False
            break
        else:
            print("What the hell did you type? type again!")
            continue
    return rolling
            
def show_results(computer_score,human_score):
    s = computer_score - human_score
    if s > 0:
        print("You lost! Computer lead by",s,"points")
    else:
        print("You won! You lead",-s,"points")
    
def main():
    computer_score = 0
    human_score = 0
    game_over = False 
    while game_over != True:
        cs = computer_move(computer_score, human_score)
        computer_score += cs
        print("Now the computer's score is",computer_score)
        print("Now your score is",human_score)
        hs = human_move(computer_score, human_score)
        human_score += hs
        print("Now the computer's score is",computer_score)
        print("Now your score is",human_score)
        game_over = is_game_over(computer_score, human_score)
    show_results(computer_score, human_score)


#Now is the main part of this programming.
instructions()
main()



        
        
    


