'''
Student name: Zhefu Peng
Student Penn ID: 29419150

'''

import random

def instructions():
    print("Here is the game instruction. I will tell you how to play.")
    print("If you roll six, you will end your turn.",end = " " )
    print("If you roll other numbers, you can continue your turn.")
    print("If you arrive at 50 points earlier than computer, you win.",end = " ")
    print("Otherwise you will lose the game.")

def computer_move():
    global human_score
    global computer_score
    global b
    b = 0
    print("Now its computer's turn.")
    computer = True
    while computer:
        d = computer_score - human_score
        if d >= 0:
            print("now the computer is leading for",d)
            #Using p as a probability to let computer decide whether roll or not.
            #When computer is not behind, the probability to roll is 50%.
            p = random.randint(1,10)
        else:
            #When computer is behind, the probability to roll is 71.4%.
            print("now the computer is behind by",-d)
            p = random.randint(4,10)
            #If computer roll a number which is larger than 5, he will roll.
        if p > 5:
            move = True
            print("The computer got",p,"so he decides to roll")
        else:
            move = False
            computer = False
            print("The computer decided not to roll because he got",p)
        while move:
            #Using character 'y' to record the score of computer in every time.
            y = random.randint(1,6)
            #Using character 'b' to record the score of computer in every turn.
            print('The computer got',y,'in this time rolling.')
            if y != 6:
                b = b + y
                print("the computer got",b,"in this turn")
                computer_score += b
                move = False
                computer = True
            else:
                print("Computer got six!His ending!")
                b = 0
                computer_score += b
                move = False
                computer = False
    else:
        print("The turn of computer ends!")
        print("In this turn computer got",b,"in total")
        print("The computer now has",computer_score,"points")
        y = 0
        b = 0
            
    


def human_move():
    global human_score
    global computer_score
    print("Now the computer score",computer_score,"Now you score",human_score)
    
    if computer_score == human_score:
        print("now you guys are tied!")
    elif computer_score > human_score:
        print("now you are behind",(computer_score - human_score))
    else:
        print("now you are leding",(human_score - computer_score))
    roll()
    

def roll():
    #Using character 'x' to record the score of computer in every turn.
    x = 0
    #Using character 'a' to record the score of user in every time.
    a = 0
    global human_score
    rolling = True
    while rolling:
        print("The number is coming.....\n")
        a = random.randint(1,6)
        if a != 6:
            x = x + a
            print("you just got",a)
            print("Now your score in this turn is",x)
            
            print("Now your total score is",human_score + x)
        else:
            print("You got six!")
            x = 0;
            break
        again = True
        while again:
            roll = input("Do you want to roll again?(y/n)")
            if roll == 'y':
                rolling = True
                again = False
            elif roll == 'n':
                rolling = False
                again = False
            else:
                print("What the hell did you type?type again!")
                continue
    print("Your score in this turn is",x)
    human_score = x + human_score
    print("Now your total score is",human_score)


def is_game_over():
    global start
    global begin
    global game
    #Decide whether the game should end or continue
    if computer_score >= 50 or human_score >= 50:
        #return True
        print("Game over")
        start = False
        begin = False
        game = False
        
        
    else:
        #return False
        print("The game will continue.")
        begin = False
        start = True
        
        


def ask_yes_or_no():
    global prompt
    global start
    global game
    #prompt = True
    while prompt:
        play = input("Whether you would like to play one more time?:")
        if play[0] == "y" or play[0] == "Y":            
            start = False
            prompt = False
            game = True
        elif play[0] == 'n' or play[0] == 'N':
            prompt = False
            start = False
            game = False
            print("Thanks for your playing!")
        else:
            print("What the held did you type?")
            continue
            
def show_results():
    global computer_score
    global human_score
    s = computer_score - human_score
    if s > 0:
        print("You lost! Computer lead by",s,"points")
    else:
        print("You won! You lead",-s,"points")
    
def main():
    global start
    global begin
    global game
    global human_score
    global computer_score
    while game:
        print("Now the game START!!!!")
        human_score = 0
        computer_score = 0
        start = True
        while start:
            begin = True
            while begin:
                computer_move()
                human_move()
                is_game_over()
                break
    
        show_results()
        prompt = True
        ask_yes_or_no()
            


#Now is the main part of this programming.
game = True
prompt = True
instructions()
human_score = 0
computer_score = 0
main()



        
        
    


