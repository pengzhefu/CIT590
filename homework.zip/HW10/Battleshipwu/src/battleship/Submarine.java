package battleship;

public class Submarine extends Ship {
	int length = 1;
	boolean[] hit = {false, true, true, true};
	Submarine() {
		super.length = length;
		super.hit = hit;
		}
	
	@Override
	String getShipType() {
		return "submarine";
	}
	
	@Override
	int getLength() {
		return length;
	}
}
