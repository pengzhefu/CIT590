package battleship;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ShipTest {

	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void testOkToPlaceShipAt() {
		fail("Not yet implemented");
	}

	@Test
	void testPlaceShipAt() {
		fail("Not yet implemented");
	}

	@Test
	void testShootAt() {
		fail("Not yet implemented");
	}

	@Test
	void testIsSunk() {
		fail("Not yet implemented");
	}

	@Test
	void testToString() {
		fail("Not yet implemented");
	}

}
