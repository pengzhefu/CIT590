package battleship;

public class Destroyer extends Ship {
	int length = 2;
	boolean[] hit = {false, false, true, true};
	Destroyer() {
		super.length = length;
		super.hit = hit;
		}
	
	@Override
	String getShipType() {
		return "destroyer";
	}
	
	@Override
	int getLength() {
		return length;
	}
}
