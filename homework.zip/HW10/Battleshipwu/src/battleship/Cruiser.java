package battleship;

public class Cruiser extends Ship {
	int length = 3;
	boolean[] hit = {false, false, false, true};
	Cruiser() {
		super.length = length;
		super.hit = hit;
		}
	
	@Override
	String getShipType() {
		return "cruiser";
	}
	
	@Override
	int getLength() {
		return length;
	}
}
