package battleship;

import java.util.Scanner;

public class BattleshipGame {
	void startGame() {
		System.out.println("!!!!!WELCOME TO THE GAME OF BATTLESHIP!!!!!\n");
		Ocean ocean = new Ocean();
		System.out.println("Your current ocean map:");
		ocean.print();
		String line = "-----------------------------\n-----------------------------\n";
		System.out.println(line + "     Shots Fired: " + ocean.getShotsFired()
				+ "\n     Hit   count: " + ocean.getHitCount() +"\n" + line);
		ocean.placeAllShipsRandomly();
		Scanner scanner = new Scanner(System.in);
		while(ocean.isGameOver() == false) {
			int m = 0, n = 0;
			boolean input = true;
			while(input) {
				try {
					System.out.println("Please input row number: ");
					m = Integer.parseInt(scanner.nextLine());
					System.out.println("Please input column number: ");
					n = Integer.parseInt(scanner.nextLine());
					if (m < 0 || m > 9 || n < 0 || n > 9) {
						System.out.println("Must input an Integer within 0 ~ 9!");
						continue;
					}
					input = false;
				}catch(Exception e) {
					System.out.println("Must input an Integer within 0 ~ 9!");
					continue;
				}
			}
			if(ocean.ships[m][n].isSunk()) ocean.shootAt(m, n);
			else {
				ocean.shootAt(m, n);
				if(ocean.ships[m][n].isSunk()) {
					System.out.println(line + "You just sank a " + ocean.ships[m][n].getShipType() + "!!!\n" + line);
				}
			}
			if(ocean.isOccupied(m, n)) System.out.println(" =====\n| hit |\n =====");
			else System.out.println(" ======\n| miss |\n ======");
			ocean.print();
			System.out.println(line + "     Shots Fired: " + ocean.getShotsFired() 
					+ "\n     Hit   count: " + ocean.getHitCount() +"\n" + line);
		}
		System.out.println(line + "   Your final score is: " + ocean.shotsFired + "\n" + line);
	}

	public static void main(String[] args) {
		BattleshipGame bg = new BattleshipGame();
		boolean playAgain = true;
		boolean wrongString = true;
		Scanner scanner = new Scanner(System.in);
		while(playAgain) {
			bg.startGame();
			while(wrongString) {
				System.out.println("Would you like to play again?(y/n)");
				String string = scanner.nextLine();
				if(string.equals("y")) {
					scanner.close();
					break;
				}else if(string.equals("n")){
					scanner.close();
					playAgain = false;
					System.out.println("Thank you for playing!! See you next time!!");
					break;
				}else {
					continue;
				}
			}
		}

	}
}