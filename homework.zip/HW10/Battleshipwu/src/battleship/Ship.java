package battleship;
/**
 * In this class you will set up the game; 
 * accept "shots" from the user; 
 * display the results; 
 * print final scores; 
 * and ask the user if he/she wants to play again. 
 * All input/output is done from here 
 * (although it uses a print() method in the Ocean class). 
 * All computation will be done in the Ocean class and the various Ship classes.
 * @author wuyan
 *
 */
public abstract class Ship {
	int bowRow;
	int bowColumn;
	// Position of the first block of a ship.
	int length;
	boolean horizontal;
	boolean [] hit = new boolean[4];
	
	abstract int getLength();
	
	int getBowRow() {
		return bowRow;
	}
	
	int getBowColumn() {
		return bowColumn;
	}
	
	boolean isHorizontal() {
		return horizontal;
	}
	
	void setBowRow(int row) {
		bowRow = row;
	}
	
	void setBowColumn(int column) {
		bowColumn = column;
	}
	
	void setHorizontal(boolean horizontal) {
		this.horizontal = horizontal;
	}
	
	abstract String getShipType();
	
	/**
	 * If we want to place a ship at a given position, we should check if all the 9 blocks(including itself) around
	 * each blocks are empty seas. If not, return false. 
	 * @param row
	 * @param column
	 * @param horizontal
	 * @param ocean
	 * @return
	 */
	boolean okToPlaceShipAt(int row, int column, boolean horizontal, Ocean ocean) {
		/*
		 * In this method we set four different parameters, edgeForRowStart, edgeForRowEnd,
		 * edgeForColumnStart and edgeForColumnEnd, to mark the start position and end position of
		 * which blocks we need to look at. These parameters varies under different circumstances.
		 * 
		 * First initialize the four parameters of 1, change their value according to the horizontal and 
		 * position, if the ship starts at the first row or column, set the RowStart or ColumnStart to 0;
		 * if the last possible row or column, set the same for the Ends to length-1; or set the ends value
		 * to length.
		 */
		int edgeForRowStart = 1, edgeForColumnStart = 1;
		int edgeForRowEnd = 1, edgeForColumnEnd = 1;
		if (row == 0) edgeForRowStart = 0;
		if (column == 0) edgeForColumnStart = 0;
		if (row == 9) edgeForRowEnd = 0;
		if (column == 9) edgeForColumnEnd = 0;
		if (length == 1) {
			if(row + length > 10 || column + length > 10) return false;
		}else{
			if (horizontal) {
				if(column + length  > 10) return false;
				if(column + length == 10) edgeForColumnEnd = length - 1;
				else edgeForColumnEnd = length;	
			}else {
				if (row + length > 10) return false;
				if (row + length == 10) edgeForRowEnd = length -1;
				else edgeForRowEnd = length;
			}
		}
		for (int i = row - edgeForRowStart; i <= row + edgeForRowEnd; i++) {
			for (int j = column - edgeForColumnStart; j <= column + edgeForColumnEnd; j++) {
				if(ocean.ships[i][j].toString() != "-") {
					return false;
				}
			}
		}
		// see if all the blocks are available.
		return true;
	}
	
	/**
	 * Assume the given place is legal to place ship.
	 * And set all the variables of all the blocks of the ship.
	 * @param row
	 * @param column
	 * @param horizontal
	 * @param ocean
	 */
	void placeShipAt(int row, int column, boolean horizontal, Ocean ocean) {
		ocean.ships[row][column].setBowColumn(column);
		ocean.ships[row][column].setBowRow(row);
		ocean.ships[row][column].length = length;
		ocean.ships[row][column].horizontal = horizontal;
		if(horizontal) {
			for(int i = column; i< column + length; i++) {
				ocean.ships[row][i] = ocean.ships[row][column];  	
			}
		}else {
			for(int i = row; i< row + length; i++) {
				ocean.ships[i][column] = ocean.ships[row][column];
			}
		}
		// set blocks to different directions according to horizontal.
	}
	
	/**
	 * After calling this method, the certain position in the hit[] array should be changed.
	 * And this certain position is the length from the input position to the bow position.
	 * @param row
	 * @param column
	 * @return
	 */
	boolean shootAt(int row, int column) {
		if(horizontal) {
			if(column >= bowColumn & column < bowColumn + length) {
				hit[column - bowColumn] = true;
				return true;
			}
			else return false;
		}else {
			if(column != bowColumn) return false;
			if(row >= bowRow & row < bowRow + length) {
				hit[row - bowRow] = true;
				return true;
			}
			else return false;
		}
	}
	
	/**
	 * This method needs all the hit[] value to be true to return true.
	 * @return
	 */
	boolean isSunk() {
		int i = 0;
		while(i < length) {
			if (hit[i] == false) return false;
			i++;
		}
		return true;	
	}
	
	@Override
	public String toString() {
		if (isSunk()) return "x";
		else return "S";
	}
	
}
