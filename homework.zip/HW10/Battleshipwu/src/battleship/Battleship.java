package battleship;
public class Battleship extends Ship {
	int length = 4;
	boolean[] hit = new boolean[4];
	Battleship() {
		super.length = length;
		super.hit = hit;
		}
	
	@Override
	String getShipType() {
		return "battleShip";
	}
	
	@Override
	int getLength() {
		return length;
	}
}
