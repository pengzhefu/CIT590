package battleship;

import java.util.Random;

public class Ocean {
	Ship[][] ships = new Ship[10][10];
	int shotsFired;
	int hitCount;
	Ocean ocean;
	Ocean() {
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				ships[i][j] = new EmptySea();
				ships[i][j].setBowRow(i);
				ships[i][j].setBowColumn(j);
			}
		}
		shotsFired = 0;
		hitCount = 0;
	}
	
	/**
	 * Place all of the four ship kinds in this method, to avoid code repeating,
	 * I conclude them in to one method: placeOneKindOfShipRandomly(Ship ship, Ocean ocean),
	 * and call that method in this one several times.
	 */
	void placeAllShipsRandomly() {
		ocean = new Ocean();
		// set a new ocean inside the Ocean class.
		int i;
		placeOneKindOfShipRandomly(new Battleship(), ocean);
		for(i = 0; i < 2; i++) {
			placeOneKindOfShipRandomly(new Cruiser(), ocean);
		}
		for(i = 0; i < 3; i++) {
			placeOneKindOfShipRandomly(new Destroyer(), ocean);
		}
		for(i = 0; i < 4; i++) {
			placeOneKindOfShipRandomly(new Submarine(), ocean);
		}
		ships = ocean.ships;
		// extract the ships array inside the object ocean and put it 
		// in the current ships array inside the class.
	}
	
	/**
	 * @param ship  :Any one of the four ship kinds.
	 * @param ocean :This parameter is set inside the Ocean class,
	 *               it contains another ships array inside it.
	 */
	private void placeOneKindOfShipRandomly(Ship ship, Ocean ocean) {
		Random random = new Random();
		boolean horizontal = random.nextInt(2) > 0 ? true: false;
		int row = random.nextInt(10);
		int column = random.nextInt(10);
		// Get the three random parameters.
			while(ship.okToPlaceShipAt(row, column, horizontal, ocean) == false) {
				// decide if the current set of parameters is legal for putting a new ship.
				horizontal = random.nextInt(2) > 0 ? true: false;
				row = random.nextInt(10);
				column = random.nextInt(10);
			}
			ship.setBowColumn(column);
			ship.setBowRow(row);
			ship.setHorizontal(horizontal);
			ship.placeShipAt(row, column, horizontal, ocean);
			// set these parameters to the ship object and all blocks of the ship
			int moveRow = horizontal == true ? 1 : ship.length;
			int moveColumn = horizontal == true? ship.length : 1;
			for(int i = row; i < row + moveRow; i++) {
				for(int j = column; j < column + moveColumn; j++) {
					ocean.ships[i][j] = ship;
					// actually change the ship object in to the new ship
				}
			}
	}
	
	/**
	 * "x" and "S" both indicate a ship in this location, so both return true,
	 * for "-" return false because its an empty sea.
	 * @param row
	 * @param column
	 * @return
	 */
	boolean isOccupied(int row, int column) {
		if(ships[row][column].toString() == "-") return false;
		else return true;
	}
	
	/**
	 * Need to change the shotsFired and hitCount here, and use the method
	 * shootAt(int row, int column) inside the ship class.
	 * @param row
	 * @param column
	 * @return
	 */
	boolean shootAt(int row, int column) {
		shotsFired++;
		ships[row][column].shootAt(row, column);
		if (ships[row][column].getShipType().equals("") == false) {
			hitCount ++;
			return true;
		}
		return false;
	}
	
	int getShotsFired() {
		return shotsFired;
	}
	
	int getHitCount() {
		return hitCount;
	}
	
	/**
	 * If a location contains "S" means there are still unsunk ships.
	 * Otherwise the game is over.
	 * @return
	 */
	boolean isGameOver() {
		for(int i = 0; i < 10; i++) {
			for(int j = 0; j < 10; j++) {
				if (ships[i][j].toString() == "S") {
					return false;
				}
			}
		}
		return true;
	}
	
	Ship[][] getShipArray(){
		return ships;
		}
	
	/**
	 * Set a string[][] array to put what we need into it.
	 * Decide whether a location has been hit and print this location
	 * with " ."(not hit) or toString()(hit).
	 */
	void print() {
		String[][] oceanCurrent = new String[11][11];
		// need an extra row and column to display the index number.
		int i, j;
		oceanCurrent[0][0] = " ";
		for(i = 1; i < 11; i++) {
			oceanCurrent[0][i] = " " + (i-1);
		}
		for(i = 1; i < 11; i++) {
			oceanCurrent[i][0] = i-1 +"";
			for(j = 1; j < 11; j++) {
				boolean isHit = ships[i-1][j-1].hit[i-1+j-1
				                                    -(ships[i-1][j-1].bowRow
				                                    +ships[i-1][j-1].bowColumn)];
				// look into the hit[] array and decide whether this place has been
				// hit before.
				if(isHit) oceanCurrent[i][j] = " " + ships[i-1][j-1].toString();
				else oceanCurrent[i][j] = " .";
			}
		}
		// all work done and print out.
		for(i = 0; i < 11; i++) {
			for(j = 0; j < 11; j++) {
				System.out.print(oceanCurrent[i][j]);
			}
			System.out.println("");
		}
	}
}

