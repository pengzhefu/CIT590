package battleship;

public class EmptySea extends Ship {
	int length = 1;
	boolean[] hit = {false, true, true, true};
	public EmptySea() {
		super.length = length;
		super.hit = hit;
		super.horizontal = true;
	}
	
	@Override
	int getLength() {
		return length;
	}
	
	@Override
	boolean shootAt(int row, int column) {
		hit[0] = true;
		return false;
	}
	
	@Override
	boolean isSunk() {
		return false;
	}
	
	@Override
	public String toString() {
		return "-";
	}

	@Override
	String getShipType() {
		return "";
	}
}
