package battleship;

import java.util.Random;

public class Ocean {

	protected Ship[][] ships = new Ship[10][10];
	protected int shotsFired;
	protected int hitCount;

	protected int[][] hitRecords = new int[10][10];

	public Ocean() {
		for (int i = 0; i < ships.length; i++) {
			for (int j = 0; j < ships.length; j++) {
				ships[i][j] = new EmptySea();
			}
		}
	}

	public void placeAllShipsRandomly() {
		/**
		 * One battleship
		 */
		Battleship battleship = new Battleship();
		Random random = new Random();
		int count = 0;

		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if (count == 1) {
					break;
				}
				boolean horizontal = random.nextBoolean();
				battleship.setBowRow(i);
				battleship.setBowColumn(j);
				battleship.setHorizontal(horizontal);
				if (battleship.okToPlaceShipAt(i, j, horizontal, this)) {
					battleship.placeShipAt(i, j, horizontal, this);
					count++;

				} else {
					battleship.setHorizontal(!horizontal);
					if (battleship.okToPlaceShipAt(i, j, !horizontal, this)) {
						battleship.placeShipAt(i, j, !horizontal, this);
						count++;
					}
				}
			}
		}

		/**
		 * Two cruisers
		 */
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if (count == 3) {
					break;
				}
				Cruiser cruiser = new Cruiser();
				boolean horizontal = random.nextBoolean();
				cruiser.setBowColumn(j);
				cruiser.setBowRow(i);
				cruiser.setHorizontal(horizontal);
				if (cruiser.okToPlaceShipAt(i, j, horizontal, this)) {
					cruiser.placeShipAt(i, j, horizontal, this);
					count++;
				} else {
					cruiser.setHorizontal(!horizontal);
					if (cruiser.okToPlaceShipAt(i, j, !horizontal, this)) {
						cruiser.placeShipAt(i, j, !horizontal, this);
						count++;
					}
				}
			}
		}

		/**
		 * Three destroyers
		 */
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if (count == 6) {
					break;
				}
				Destroyer destroyer = new Destroyer();
				boolean horizontal = random.nextBoolean();
				destroyer.setBowColumn(j);
				destroyer.setBowRow(i);
				destroyer.setHorizontal(horizontal);
				if (destroyer.okToPlaceShipAt(i, j, horizontal, this)) {
					destroyer.placeShipAt(i, j, horizontal, this);
					count++;
				} else {
					destroyer.setHorizontal(!horizontal);
					if (destroyer.okToPlaceShipAt(i, j, !horizontal, this)) {
						destroyer.placeShipAt(i, j, !horizontal, this);
						count++;
					}
				}
			}
		}

		// printShipArray();

		/**
		 * Four submarines
		 */
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if (count == 10) {
					break;
				}
				Submarine submarine = new Submarine();
				boolean horizontal = random.nextBoolean();
				submarine.setBowColumn(j);
				submarine.setBowRow(i);
				submarine.setHorizontal(horizontal);
				if (submarine.okToPlaceShipAt(i, j, horizontal, this)) {
					submarine.placeShipAt(i, j, horizontal, this);
					// System.out.println(i + "," + j + "," + horizontal);
					// printShipArray();
					count++;
				} else {
					submarine.setHorizontal(!horizontal);
					if (submarine.okToPlaceShipAt(i, j, !horizontal, this)) {
						submarine.placeShipAt(i, j, !horizontal, this);
						// System.out.println(i + "," + j + "," + horizontal);
						// printShipArray();
						count++;
					}
				}
			}
		}


	}


	public boolean isOccupied(int row, int column) {
		if (row >= 0 && row < ships.length && column >= 0 && column < ships.length) {
			if (!(ships[row][column] instanceof EmptySea)) {
				return true;
			}
		}

		return false;
	}

	public boolean shootAt(int row, int column) {
		if (row >= 0 && row < ships.length && column >= 0 && column < ships.length) {
			hitRecords[row][column] += 1;
			return ships[row][column].shootAt(row, column);
		}
		return false;

	}

	public int getShotsFired() {
		return shotsFired;
	}

	public int getHitCount() {
		return hitCount;
	}

	public void setShotsFired(int shotsFired) {
		this.shotsFired = shotsFired;
	}

	public void setHitCount(int hitCount) {
		this.hitCount = hitCount;
	}

	public boolean isGameOver() {
		for (int i = 0; i < ships.length; i++) {
			for (int j = 0; j < ships.length; j++) {
				if (!(ships[i][j] instanceof EmptySea) && !ships[i][j].isSunk()) {
					return false;
				}
			}
		}

		return true;
	}

	public Ship[][] getShipArray() {
		return ships;
	}

	public void print() {

		for (int i = 0; i < hitRecords.length; i++) {
			for (int j = 0; j < hitRecords.length; j++) {
				if (hitRecords[i][j] == 0) {
					System.out.print(".");
				} else {
					System.out.print(ships[i][j].toString());
				}
			}
			System.out.println();
		}

		// for (int i = 0; i < ships.length; i++) {
		// for (int j = 0; j < ships.length; j++) {
		// System.out.print(ships[i][j].toString());
		// }
		// System.out.println();
		// }
	}
}
