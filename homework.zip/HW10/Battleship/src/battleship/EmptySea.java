package battleship;

public class EmptySea extends Ship{
	
	public EmptySea(){
		length = 1;
        
	}
	
	public int getLength(){
		return length;
	}
	
	@Override 
	public String getShipType(){
		return "null";
	}
	
	@Override 
	public boolean shootAt(int row, int column){
		return false;
	}
	
	@Override 
	public boolean isSunk(){
		return false;
	}
	
	@Override 
	public String toString(){
		return "-";
	}

}
