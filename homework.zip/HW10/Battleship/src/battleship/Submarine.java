package battleship;

public class Submarine extends Ship{
	
	public Submarine(){
		length = 1;
        
	}
	
	public int getLength(){
		return length;
	}
	
	@Override 
	public String getShipType(){
		return "submarine";
	}

}
