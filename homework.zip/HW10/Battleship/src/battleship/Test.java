//package battleship;
//
//public class Test {
//
//	public static void main(String[] args) {
//		Ocean ocean = new Ocean();
//		ocean.placeAllShipsRandomly();
//
//		for (int i = 0; i < 10; i++) {
//			for (int j = 0; j < 10; j++) {
//				ocean.shootAt(i, j);
//			}
//		}
//
//		ocean.print();
//
//		// Battleship battleship = new Battleship();
//		// int row = 0;
//		// int column = 0;
//		// boolean horizontal = true;
//		// battleship.setBowColumn(column);
//		// battleship.setBowRow(row);
//		// battleship.setHorizontal(horizontal);
//		// if (battleship.okToPlaceShipAt(row, column, horizontal, ocean)) {
//		// battleship.placeShipAt(row, column, horizontal, ocean);
//		// }
//		//
//		// Cruiser cruiser = new Cruiser();
//		// row = 5;
//		// column = 1;
//		// // horizontal = false;
//		// cruiser.setBowColumn(column);
//		// cruiser.setBowRow(row);
//		// cruiser.setHorizontal(horizontal);
//		// if (cruiser.okToPlaceShipAt(row, column, horizontal, ocean)) {
//		// cruiser.placeShipAt(row, column, horizontal, ocean);
//		// }
//		//
//		// Ship[][] ships = ocean.ships;
//		// for (Ship[] ships2 : ships) {
//		// for (Ship ship : ships2) {
//		// // System.out.print(ship.getClass().getSimpleName() + " ");
//		// System.out.print(ship);
//		//
//		// }
//		//
//		// System.out.println();
//		// }
//		//
//		// System.out.println(ocean.shootAt(0, 1));
//		// ;
//		// System.out.println(ships[0][0].isSunk());
//		//
//		// System.out.println(ocean.shootAt(0, 2));
//		// ;
//		// System.out.println(ships[0][0].isSunk());
//		//
//		// System.out.println(ocean.shootAt(0, 3));
//		// ;
//		// System.out.println(ships[0][0].isSunk());
//		//
//		// System.out.println(ocean.shootAt(0, 0));
//		// ;
//		// System.out.println(ships[0][0].isSunk());
//		//
//		// System.out.println(ocean.shootAt(5, 1));
//		// System.out.println(ships[5][1].isSunk());
//		// System.out.println(ships[5][2].isSunk());
//		// System.out.println(ships[5][3].isSunk());
//		//
//		//
//		// System.out.println("--------------------");
//		// System.out.println(ocean.shootAt(5, 2));
//		// System.out.println(ships[5][1].isSunk());
//		// System.out.println(ships[5][2].isSunk());
//		// System.out.println(ships[5][3].isSunk());
//		//
//		//
//		// System.out.println("--------------------");
//		//
//		// System.out.println(ocean.shootAt(5, 3));
//		// System.out.println("--------------------");
//		// System.out.println(ships[5][1].isSunk());
//		// System.out.println(ships[5][2].isSunk());
//		// System.out.println(ships[5][3].isSunk());
//
//		// for (Ship[] ships2 : ships) {
//		// for (Ship ship : ships2) {
//		// // System.out.print(ship.getClass().getSimpleName() + " ");
//		// System.out.print(ship);
//		//
//		// }
//		//
//		// System.out.println();
//		// }
//	}
//
//}
