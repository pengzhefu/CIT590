package battleship;

import java.util.Scanner;

public class BattleshipGame {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Ocean ocean = new Ocean();
		ocean.placeAllShipsRandomly();

		// Ship[][] ships = ocean.ships;
		// for (Ship[] ships2 : ships) {
		// for (Ship ship : ships2) {
		// System.out.print(ship);
		// }
		//
		// System.out.println();
		// }

		Scanner sc = new Scanner(System.in);
		System.out.println("===========Welcome to Battleship Game===========");
		System.out.println();
		int row = 0;
		int column = 0;
		String tip = "Y";
		do {
			try {
				ocean.print();
				System.out.println();
				System.out.println("Please Enter a row and column number, space between Spaces:");
				String enterStr = sc.nextLine();
				if (enterStr != null && enterStr.length() != 0) {
					String[] split = enterStr.split("\\s");
					row = Integer.valueOf(split[0]);
					column = Integer.valueOf(split[1]);
				}
				if (ocean.shootAt(row, column)) {
					ocean.setHitCount(ocean.getHitCount() + 1);
					if (ocean.getShipArray()[row][column].isSunk()) {
						System.out.println("You just sank a " + ocean.getShipArray()[row][column].getShipType() + ".");
					}
				}
				ocean.setShotsFired(ocean.getShotsFired() + 1);

				// ocean.print();

				// Ship[][] shipArray = ocean.getShipArray();
				// for (int i = 0; i < shipArray.length; i++) {
				// for (int j = 0; j < shipArray.length; j++) {
				// if (shipArray[i][j].isSunk()) {
				// System.out.println("You just sank a " +
				// shipArray[i][j].getShipType() + ".");
				// }
				// }
				// }

				if (ocean.isGameOver()) {
					ocean.print();
					System.out.println("game is over, shotsFired : " + ocean.getShotsFired() + ", hitCount : "
							+ ocean.getHitCount());
					System.out.println();
					System.out.println("Do you wants to play again? Y or N");
					tip = sc.nextLine();
					ocean = new Ocean();
					ocean.placeAllShipsRandomly();
				}
			} catch (Exception e) {
				System.out.println("Incorrect input format！！！");
			}

		} while (tip.equalsIgnoreCase("Y"));

	}

}
