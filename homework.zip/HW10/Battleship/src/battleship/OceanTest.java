package battleship;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class OceanTest {

	@Test
	public void testOccupied() {
		Ocean ocean = new Ocean();
		assertEquals(ocean.isOccupied(3, 6), false);
	}
	
	

	@Test
	public void testShootAt() {
		Ocean ocean = new Ocean();
		assertEquals(ocean.shootAt(0, 0), false);
	}
	
	

	@Test
	public void testGameOver() {
		Ocean ocean = new Ocean();
		ocean.placeAllShipsRandomly();
		assertEquals(ocean.isGameOver(), false);
	}
}
