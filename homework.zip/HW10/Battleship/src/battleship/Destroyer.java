package battleship;

public class Destroyer extends Ship{
	
	public Destroyer(){
		length = 2;
        
	}
	
	public int getLength(){
		return length;
	}
	
	@Override 
	public String getShipType(){
		return "destroyer";
	}

}
