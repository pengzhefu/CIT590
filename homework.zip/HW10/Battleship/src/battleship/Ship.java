package battleship;

public abstract class Ship {

	protected int bowRow, bowColumn, length;
	protected boolean horizontal;
	protected boolean[] hit = new boolean[4];

	public abstract int getLength();

	public int getBowRow() {

		return bowRow;
	}

	public int getBowColumn() {

		return bowColumn;
	}

	public boolean isHorizontal() {

		return horizontal;
	}

	public void setBowRow(int row) {

		bowRow = row;
	}

	public void setBowColumn(int column) {

		bowColumn = column;
	}

	public void setHorizontal(boolean Horizontal) {

		horizontal = Horizontal;
	}

	public abstract String getShipType();

	/**
	 * 如何判断指定位置是否是合法，只需要判断，这个Ship占据的位置 和 周围一圈（垂直、水平、斜对角）的位置都是空的（EmptySea）
	 * 
	 * @param row
	 * @param column
	 * @param horizontal
	 * @param ocean
	 * @return
	 */
	public boolean okToPlaceShipAt(int row, int column, boolean horizontal, Ocean ocean) {

		Ship[][] ships = ocean.getShipArray();

		if (horizontal) {
			int startRow = row - 1;
			int endRow = row + 1;
			int startColumn = column - 1;
			int endColumn = column + length;

			if (startRow < 0) {
				startRow = 0;
			}

			if (endRow >= ships.length) {
				endRow = ships.length - 1;
			}

			if (startColumn < 0) {
				startColumn = 0;
			}

			if (endColumn >= ships.length) {
				return false;
			}

			for (int i = startRow; i <= endRow && i < ships.length && i >= 0; i++) {
				for (int j = startColumn; j <= endColumn && j < ships.length && j >= 0; j++) {
					Ship ship2 = ships[i][j];
					if (!(ship2 instanceof EmptySea)) {
						return false;
					}
				}
			}
		} else {
			int startRow = row - 1;
			int endRow = row + length;
			int startColumn = column - 1;
			int endColumn = column + 1;

			if (startRow < 0) {
				startRow = 0;
			}

			if (endRow >= ships.length) {
				return false;
			}

			if (startColumn < 0) {
				startColumn = 0;
			}

			if (endColumn >= ships.length) {
				endColumn = ships.length - 1;
			}

			for (int i = startRow; i <= endRow && i < ships.length && i >= 0; i++) {
				for (int j = startColumn; j <= endColumn && j < ships.length && j >= 0; j++) {
					Ship ship2 = ships[i][j];
					if (!(ship2 instanceof EmptySea)) {
						return false;
					}
				}
			}
		}

		return true;
	}

	public void placeShipAt(int row, int column, boolean horizontal, Ocean ocean) {
		if (horizontal) {
			for (int c = column; c < column + length && c < ocean.getShipArray().length; c++) {
				ocean.getShipArray()[row][c] = this;
			}
		} else {
			for (int r = row; r < row + length && r < ocean.getShipArray().length; r++) {
				ocean.getShipArray()[r][column] = this;
			}
		}
	}

	public boolean shootAt(int row, int column) {
		if (!isSunk()) {
			if (horizontal) {
				if (row == bowRow && column < bowColumn + length && column >= bowColumn) {
					hit[column - bowColumn] = true;
					return true;
				}

			} else {
				if (column == bowColumn && row < bowRow + length && row >= bowRow) {
					hit[row - bowRow] = true;
					return true;
				}
			}
		}

		return false;

	}

	public boolean isSunk() {
		boolean sunk = false;
		int j = 0;
		for (int i = 0; i < length; i++) {
			if (hit[i]) {
				j++;
			}
		}

		if (j == length) {
			sunk = true;
		}

		return sunk;
	}

	@Override
	public String toString() {
		if (isSunk()) {
			return "S";
		} else {
			return "x";
		}
	}

}
