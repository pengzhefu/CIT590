package battleship;

import static org.junit.Assert.*;

import org.junit.Test;

public class ShipTest {

	@Test
	public void testOkToPlaceShipAt() {

		Ocean ocean = new Ocean();
		Battleship battleship = new Battleship();
		int row = 0;
		int column = 0;
		boolean horizontal = true;
		battleship.setBowColumn(column);
		battleship.setBowRow(row);
		battleship.setHorizontal(horizontal);
		assertEquals(battleship.okToPlaceShipAt(0, 0, true, ocean), true);

		Cruiser cruiser = new Cruiser();
		horizontal = false;
		cruiser.setBowColumn(column);
		cruiser.setBowRow(row);
		cruiser.setHorizontal(horizontal);
		assertEquals(battleship.okToPlaceShipAt(0, 0, true, ocean), false);
	}

	@Test
	public void testOkToPlaceShipAt2() {

		Ocean ocean = new Ocean();
		Battleship battleship = new Battleship();
		int row = 0;
		int column = 0;
		boolean horizontal = true;
		battleship.setBowColumn(column);
		battleship.setBowRow(row);
		battleship.setHorizontal(horizontal);
		if (battleship.okToPlaceShipAt(row, column, horizontal, ocean)) {
			battleship.placeShipAt(row, column, horizontal, ocean);
		}
		Cruiser cruiser = new Cruiser();
		horizontal = false;
		cruiser.setBowColumn(column);
		cruiser.setBowRow(row);
		cruiser.setHorizontal(horizontal);
		assertEquals(battleship.okToPlaceShipAt(0, 0, true, ocean), false);
	}

	@Test
	public void testShootAt() {
		Cruiser cruiser = new Cruiser();
		cruiser.setHorizontal(false);
		cruiser.setBowRow(6);
		cruiser.setBowColumn(5);
		assertEquals(cruiser.shootAt(8, 5), true);
	}

	@Test
	public void testShootAt2() {
		Ocean ocean = new Ocean();
		Cruiser cruiser = new Cruiser();
		int row = 5;
		int column = 1;
		boolean horizontal = false;
		cruiser.setBowColumn(column);
		cruiser.setBowRow(row);
		cruiser.setHorizontal(horizontal);
		cruiser.placeShipAt(row, column, horizontal, ocean);
		assertEquals(ocean.shootAt(5, 1), true);
		assertEquals(ocean.shootAt(6, 1), true);
		assertEquals(ocean.shootAt(7, 1), true);
	}

	@Test
	public void testSunk() {
		Destroyer destroyer = new Destroyer();
		assertEquals(destroyer.isSunk(), false);
	}

	@Test
	public void testSunk2() {
		Ocean ocean = new Ocean();
		Cruiser cruiser = new Cruiser();
		int row = 5;
		int column = 1;
		boolean horizontal = true;
		cruiser.setBowRow(row);
		cruiser.setBowColumn(column);
		cruiser.setHorizontal(horizontal);
		cruiser.placeShipAt(row, column, horizontal, ocean);

		ocean.shootAt(5, 1);
		ocean.shootAt(5, 2);
		ocean.shootAt(5, 3);

		assertEquals(cruiser.isSunk(), true);
	}

}
