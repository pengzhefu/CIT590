package battleship;

public class Cruiser extends Ship{
	
	public Cruiser(){
		length = 3;
        
	}
	
	public int getLength(){
		return length;
	}
	
	@Override 
	public String getShipType(){
		return "cruiser";
	}

}
