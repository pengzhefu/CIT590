package percolation;

import static org.junit.Assert.*;
import org.junit.Test;


/**
 * Percolation Class test
 * @author ZHANG Haiming
 * Penn ID: 62923617
 *
 */
public class PercolationTest {
	

	/**
	 * test ground function
	 * @return void
	 */
	@Test
	public void testground() {
		// 50*50 ground
		int n = 50;
		// initial probability 0.6
		double p =0.6;
		// repeat 50 times 
		int iter = 50;
		int number = 0;
		for (int i = 0; i < iter; i++){
			int [][] m = Percolation.ground(n,p);
			// record number of 1's 
			for (int x = 0; x < m.length; x++){
				for (int y = 0; y < m.length; y++){
					if (m[x][y]==1){
						number += 1;
					}
				}
			}
		}
		// total number of element
		double totalNumber = 50*50*50;
		boolean m = false;
		// probability of number of 1's in a close range of p
		if ((number/totalNumber) >= (p-0.01) && (number/totalNumber) <=( p+0.01)){
			m = true;
		}
		assertTrue(m);
	}
	
	
	/**
	 * test seep function
	 * @return void
	 */
	@Test
	public void testseep() {
		// set test ground
		int [][] testground1 = {{0, 1, 1, 0, 1}, 
				                {1, 0, 0, 0, 0},
		                        {1, 1, 0, 1, 0}, 
		                        {0, 0, 0, 1, 0}, 
		                        {0, 0, 1, 0, 1}};
		
		// perform seep
		for (int i = 0; i < testground1.length-1; i++){
			Percolation.seep(testground1, i);
		}
	    
		// set expected result ground
		int [][] result1 = {{2, 1, 1, 2, 1}, 
                            {1, 2, 2, 2, 2},
                            {1, 1, 2, 1, 2}, 
                            {2, 2, 2, 1, 2}, 
                            {2, 2, 1, 0, 1}};
		
		// compare each row of both test and expected ground 
	    for (int i = 0; i < testground1.length; i++){
	    	for(int j = 0; j < testground1.length; j++){
	    		assertEquals(testground1[i][j],result1[i][j]);
	    	}
	    }  
	}
	
	
	/**
	 * test percolate function
	 * @return void
	 */
    @Test
    public void testpercolate() {
    	// set test ground
    	int [][] testground2 = {{0, 1, 1, 0, 1}, 
                                {1, 0, 0, 0, 0},
                                {1, 1, 0, 1, 0}, 
                                {0, 0, 0, 1, 0}, 
                                {0, 0, 1, 0, 1}};
    	// set test ground
    	int [][] testground3 = {{0, 1, 1, 0, 1}, 
                                {1, 0, 0, 0, 0},
                                {0, 1, 0, 1, 0}, 
                                {0, 0, 1, 0, 1}, 
                                {0, 0, 1, 0, 1}};
    	
    	// perform seep
    	for (int i = 0; i < testground2.length-1; i++){
			Percolation.seep(testground2, i);
			Percolation.seep(testground3, i);
		}
    	
    	assertTrue(Percolation.percolate(testground2));
    	assertFalse(Percolation.percolate(testground3));
    }
}
