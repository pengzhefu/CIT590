package percolation;

/**
 * Percolation Class
 * @author ZHANG Haiming
 * Penn ID: 62923617
 *
 */
public class Percolation {
	
	/**
	 * Static method to get ground
	 * @param int n, double p
	 * @return 2-dimensional array
	 */
	public static int[][] ground(int n, double p) {
		int [][] grand = new int [n][n];
		// assign each element a random number
		for (int i = 0; i < n; i++){
			for (int j = 0; j < n; j++){
				double m = Math.random();
				if (m < p){
					// sand grain
					grand[i][j] = 1 ;
				}
				
				else{
					// empty
					grand[i][j] = 0;
				}	
			}
		}
		return grand;
	}
	
	
	/**
	 * Static method to seep
	 * @param int[][] ground, int row
	 * @return void
	 */
	public static void seep(int[][] ground, int row){
		// first row to seep
		if (row == 0){
			// flow down
			for (int i =0; i < ground[0].length; i++){
				if (ground[0][i] == 0){
					ground[0][i]=2;
					if (ground[1][i]==0){
						ground[1][i]=2;
					}
				}
			}
		}
		// other rows to seep
		else{
			// flow down
			for (int i = 0; i < ground[row].length; i++){
				if ((ground[row][i]==2) && (ground[row+1][i]==0)){
					ground[row+1][i] = 2;
				}
			}
		}
		// flow horizontally left to right 
		for (int i = 0; i < ground[row].length-1; i++){
			if ((ground[row+1][i]==2) && (ground[row+1][i+1]==0)){
					ground[row+1][i+1] = 2;
			}
		}
		// flow horizontally right to left
		for (int i = ground[row].length-1; i > 0; i--){
			if ((ground[row+1][i]==2) && (ground[row+1][i-1]==0)){
				ground[row+1][i-1] = 2;
			}
		}
	}			
	
	
	/**
	 * Static method to percolate
	 * @param int[][] ground
	 * @return boolean
	 */
	public static boolean percolate(int[][] ground){
		boolean a = false;
		for (int i = 0; i < ground.length; i++){
			// any element in bottom row is water
			if (ground[ground.length-1][i]==2){
				a = true;
			}
		}
		return a;
	}
	
	
	/**
	 * Static method to find probability
	 * @param int[][] ground
	 * @return boolean
	 */
	public static double findProbability(int n){
		// initialize with probability 0.6
		double p = 0.6;
		// delta change to be 0.05 
		double delta = 0.05;
		// repeat 500 times 
		double repeat = 500;
		boolean notfind = true;
		while (notfind) {
			int seeped = 0;
			for (int i = 0; i < repeat; i++){
				int [][] m = Percolation.ground(n,p);
				for (int j = 0; j < m.length-1; j++){
					seep(m,j);
				}
				if (Percolation.percolate(m)==true){
					// recode seeped number 
					seeped += 1;
				}
			}
			double newDelta = Percolation.changedelta(seeped,repeat,delta);
			
			// successfully seeped probability smaller than 0.5-delta
			if ((seeped/repeat) < (0.5-newDelta)) {
				p -= newDelta;
				continue;
			}

			// successfully seeped probability bigger than 0.5+delta
			else if ((seeped/repeat) > (0.5+newDelta)) {
				p += newDelta;
				continue;
			}
			// successfully seeped probability in the range (0.5-delta,0.5+delta)
			else{
				notfind =false;
			}
		
	    }
		return p;
	}
	
	/**
	 * Static method to change delta
	 * @param int seep, double iteration, double delta
	 * @return double
	 */

	public static double changedelta(int seep, double repeat, double delta){
		// get probability
		double prob = seep / repeat;
		// probability  far to target range
		if ((prob <= 0.5*(0.5-delta)) || (prob >= 1.5*(0.5+delta))){
			delta = delta / 5;
		}
		// probability close to target range
		else if ((prob <= 0.9*(0.5-delta)) || (prob >= 1.1*(0.5+delta))){
			delta = delta / 10;
		}

	   return delta;
	}
	
	public static void main(String[] args) {
		// set sizes of ground
		int[] size = {50,100,200};
		for (int i =0; i < size.length; i++){
			double m = Percolation.findProbability(size[i]);
			System.out.println("The packing probability for "+size[i]+"*"+size[i]+" ground"+" is: "+ String.format("%.2f",m));
		}
	}
}
		


