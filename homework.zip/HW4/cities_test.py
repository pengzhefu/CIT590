#Student name: Zhefu Peng
#Student Penn ID: 29419150

import random
import unittest
from cities import *

file_name = "D:\\Courses&Assignments\\cit590\\homework\\HW4\\city-data.txt"

class TestCities(unittest.TestCase):

    def test_computer_total_distance(self):
        road_map = [('s1', 'c1', 2.0, 1.0), ('s2', 'c2', 9.0, 4.0), ('s3', 'c3', 6.0, 6.0), ('s4', 'city4', 9.0, 2.0), ('s1', 'c1', 2.0, 1.0)]
        self.assertEqual(round(compute_total_distance(road_map),2), 23.29)
        road_map = [('state1', 'city1', 2.0, 1.0), ('state2', 'city2', 3.0, 4.0), ('state3', 'city3', 6.0, 6.0), ('state4', 'city4', 9.0, 2.0), ('state1', 'city1', 2.0, 1.0)]
        self.assertEqual(round(compute_total_distance(road_map),2), 18.84)




    def test_swap_cities(self):
        self.assertEqual(swap_cities(read_cities(file_name), 0, 1)[0][0],
                        ('Alaska', 'Juneau', 58.301935, -134.41974))
        self.assertEqual(swap_cities(read_cities(file_name), 2, 49)[0][2],
                        ('Wyoming', 'Cheyenne', 41.145548, -104.802042))
        self.assertEqual(swap_cities(read_cities(file_name), 3, 46)[1],
                         974.8221032552449)
        self.assertEqual(swap_cities(read_cities(file_name), 2, 22)[1],
                         1089.7974072586974)
        road_map = [('state1', 'city1', 2.0, 1.0), ('state2', 'city2', 3.5, 4.0), ('state3', 'city3', 6.0, 6.0), ('state4', 'city4', 9.0, 2.0), ('state1', 'city1', 2.0, 1.0)]
        self.assertEqual(round(swap_cities(road_map, 1, 2)[1], 2), 22.53)
        road_map = [('state1', 'city1', 2.0, 1.0), ('state2', 'city2', 3.5, 4.0), ('state3', 'city3', 6.0, 6.0), ('state4', 'city4', 9.0, 2.0), ('state1', 'city1', 2.0, 1.0)]
        self.assertEqual(round(swap_cities(road_map, 2, 2)[1], 2), 18.63)
      
######Swap function passed the test
        


    def test_find_best_cycle(self):
        
        road_map = [('state1', 'city1', 2.0, 1.0), ('state2', 'city2', 9.0, 4.0), ('state3', 'city3', 6.0, 6.0), ('state4', 'city4', 9.0, 2.0), ('state1', 'city1', 2.0, 1.0)]
        self.assertEqual(round(find_best_cycle(road_map)[1], 2), 19.08)

        
unittest.main()

