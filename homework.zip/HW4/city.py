#Student name: Zhefu Peng
#Student Penn ID: 29419150


#The path and the name of the certain file
file_name = "D:\\Courses&Assignments\\cit590\\homework\\HW4\\city-data.txt"
index1 = 0
index2 = 0

import random
import math

def read_cities(file_name):
    f = open(file_name)
    lines = f.readlines()
    road_map = []
    for line in lines:
        #Clear the table
        line_change = line.split('\t')
        #Make string be the float.
        line_change[2] = float(line_change[2])
        line_change[3] = float(line_change[3])
        #line_change[3] = round(line_change[2],2)
        road_map.append(tuple(line_change))
    road_map.append(road_map[0])
    f.close()    
    return road_map
    

def print_cities(road_map):
    #Since we do not need to test, we need not to print a list.
    #Just use the print function.
    for i in range(0,50):
        print('City: {0}, Approxiamtely Lattitude:{1},\
              Approximately Altitude:{2}\n'.format(road_map[i][1],round(road_map[i][2],2),round(road_map[i][3],2)))

    print("*******************************************************************")
              


def compute_total_distance(road_map):
    #Initialization
    total_distance = 0
    Lat1 = 0
    Lat2 = 0
    Alt1 = 0
    Alt2 = 0
    #Calculating the total distance
    for i in range(0,len(road_map)-1):
        Lat1 = road_map[i][2]
        Lat2 = road_map[i+1][2]
        Alt1 = road_map[i][3]
        Alt2 = road_map[i+1][3]
        Lat_change = abs(Lat1 - Lat2)
        Alt_change = abs(Alt1 - Alt2)
        total_distance += math.sqrt(Lat_change**2 + Alt_change**2)
        
    return total_distance


def swap_cities(road_map, index1, index2):
    new_road_map = road_map
    
    #Judge the index number whether they are same.
    if index1 != index2:
        new_road_map[index1], new_road_map[index2] = new_road_map[index2], new_road_map[index1]
    else:
        pass
    #new_road_map = road_map
    new_total_distance = compute_total_distance(new_road_map)
    return(new_road_map, new_total_distance)

    
def find_best_cycle(road_map):
    current_distance = compute_total_distance(road_map)
    shortest_road_map = []
    new_road_map = list(road_map)
    #changeable_road_map = list(road_map)
    for i in range(0,50):
        for index1 in range(1,50):
            for index2 in range(index1,50):
                a= swap_cities(new_road_map, index1, index2)
                if a[1] < current_distance:
                    current_distance = a[1]
                    shortest_road_map = list(a[0])
                else:
                    pass
            new_road_map = list(shortest_road_map)
    #return a list which includes the road map & least distance
    #help me need not to calculate the least distance again
    return [shortest_road_map, current_distance]


def print_map(road_map):
    total_dis = 0
    for i in range (0, len(road_map)-1):
        dis_x = abs(road_map[i][2] - road_map[i+1][2])
        dis_y = abs(road_map[i][3] - road_map[i+1][3])
        dis_total = math.sqrt((dis_x ** 2) + (dis_y ** 2))
        print('From',road_map[i][1], '>>>>>>>>>>>', road_map[i+1][1], '\nThe distance is:', dis_total, '\n')
        total_dis += dis_total
    print("**********************************************************************")
    print('The shortest total distance is:', total_dis)
    print("=====================================================================")
    

def main():
   
    road_map = read_cities("D:\\Courses&Assignments\\cit590\\homework\\HW4\\city-data.txt")
    print_cities(road_map)
    
    print('The best cycle is:\n')

    Possible_distance = []
    Possible_map = []
    #Starting the 3 times procedure:
    for i in range(0,3):
        
        #Making a new road_map, which has a new origin.
        #Using shuffle is to change the prigin.
        rm = road_map[0:50]
        random.shuffle(rm)

        #Appending the new origin as the new desitination, make a new cycle.
        rm.append(rm[0])
        road_map = rm
        b = find_best_cycle(road_map)
        Possible_road_map = b[0]
        Possible_least_distance = b[1]
        #Using these print functions to make sure that we pick the right map
        print("The origin is:", Possible_road_map[0][1],'dest is',Possible_road_map[49][1])
        print("Possible least distance is:",Possible_least_distance)
        
        Possible_map.append(Possible_road_map)
        Possible_distance.append(Possible_least_distance)
        
    least_distance = min(Possible_distance)
    
    road_map = Possible_map[Possible_distance.index(least_distance)]
    print_map(road_map)
    

if __name__ == "__main__":
    main()
