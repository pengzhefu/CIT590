# Name: Mingxuan Sun
# Penn ID: 55323554

from math import *
import random
def read_cities(file_name):
    """Read in the cities from the given file_name, and return them as a list of fourtuples:
    [(state, city, latitude, longitude), ...] Use this as your initial road_map, that is,
    the cycle Alabama → Alaska → Arizona → ... → Wyoming →Alabama."""
    file = open(file_name, 'r')
    lines = file.readlines()
    road_map = []
    for line in lines:
        new_line = line.split('\t')
        new_line[2] = float(new_line[2])
        new_line[3] = float(new_line[3])
        new_line = tuple(new_line)
        road_map.append(new_line)
    file.close()
    road_map.append(road_map[0])
    return road_map

def print_cities(road_map):
    """Prints a list of cities, along with their locations. Print only one or two digits
    after the decimal point."""
    List = road_map
    i = 0
    for i in range (len(road_map)):
        List[i] = list(List[i])
        List[i][2] = round(List[i][2], 1)
        List[i][3] = round(List[i][3], 1)
        List[i] = tuple(List[i])
    print(List)

def computer_total_distance(road_map):
    """Returns, as a floating point number, the sum of the distances of all the connections
    in the road_map. Remember that it's a cycle, so that (for example) in the initial road_map,
    Wyoming connects to Alabama. Note: The Earth is not flat so Euclidean distance will not
    be the actual *physical* distance between two cities but, as usual, let’s ignore physics."""
    i = 0
    total_distance = 0
    for i in range (len(road_map)-1):
        distance_x = abs(road_map[i][2] - road_map[i+1][2])
        distance_y = abs(road_map[i][3] - road_map[i+1][3])
        distance = sqrt(pow(distance_x, 2) + pow(distance_y, 2))
        total_distance += distance
    return total_distance

def swap_cities(road_map, index1, index2):
    """Take the city at location index1 in the road_map, and the city at location index2,
    swap their positions in the road_map, compute the new total distance, and return the
    tuple (new_road_map, new_total_distance). Allow the possibility
    that index1=index2, and handle this case correctly."""
    if index1 != index2:
        road_map[index1], road_map[index2] = road_map[index2], road_map[index1]
    else:
        pass
    new_road_map = road_map
    new_total_distance = computer_total_distance(new_road_map)
    return(new_road_map, new_total_distance)

def find_best_cycle(road_map):
    """Using swap_cities, find the swap that reduces the total distance by the biggest
    amount. Repeat until you have performed 1000 swaps or until no swap can further
    decrease the total distance. This algorithm is called hill climbing, and your solution
    is a local optimum."""
    best_cycle = computer_total_distance(road_map)
    best_roadmap = road_map
    i = 0
    while i < 999:
        #random.seed(1)
        index1 = random.randint(1, 49)
        #random.seed(2)
        index2 = random.randint(1, 49)
        if swap_cities(road_map, index1, index2)[1] < best_cycle:
            best_cycle = swap_cities(road_map, index1, index2)[1]
            best_roadmap = swap_cities(road_map, index1, index2)[0]
        else:
            pass
        i += 1
    return (best_roadmap, best_cycle)

def print_map(road_map):
    """Prints, in an easily understandable format, the cities and their connections, along
    with the cost for each connection and the total cost."""
    i = 0
    for i in range (len(road_map)-1):
        cost_x = abs(road_map[i][2] - road_map[i+1][2])
        cost_y = abs(road_map[i][3] - road_map[i+1][3])
        cost = sqrt(pow(cost_x, 2) + pow(cost_y, 2))
        print(road_map[i][1], 'is connected to', road_map[i+1][1], '\tThe cost is:', cost, '\n')
    print('Total cost is:', find_best_cycle(road_map)[1])

def main():
    """Reads in and prints out the city data, then creates the "best" cycle and prints it out."""
    road_map = read_cities("D:\\Courses&Assignments\\cit590\\homework\\HW4\\city-data.txt")
    print_cities(road_map)
    print()
    print('The best cycle is:\n')
    print_map(find_best_cycle(road_map)[0])

main()

