import math
import random

def read_cities(file_name):
    f = open(file_name, 'r')
    road_map = []
    for each_line in f:
        line = each_line.split('\t')
        line[2] = float(line[2])
        line[3] = float(line[3])
        line = tuple(line)
        road_map.append(line)
        
    f.close()
    road_map.append(road_map[0])
    return road_map


def print_cities(road_map):
    print('===============================================================================')
    print('\t The initial road map is: \n')
    for i in range (len(road_map)):
        print('City:', road_map[i][1], 'Latitude:','%.2f' % road_map[i][2], 'Longitude:','%.2f' % road_map[i][3],'\n')
    print('===============================================================================')

def compute_total_distance(road_map):
    total_distance = 0
    for i in range (len(road_map)-1):
      total_distance += math.sqrt((pow((road_map[i+1][2] - road_map[i][2]),2))
                                  + (pow((road_map[i+1][3] - road_map[i][3]),2)))
    return total_distance

def swap_cities(road_map, index1, index2):
    rm = road_map
    if index1 != index2:
        rm[index1], rm[index2] = rm[index2], rm[index1]
    else:
        pass

    new_road_map = rm
    new_total_distance = compute_total_distance(new_road_map)
    return (new_road_map,new_total_distance)
        
def find_best_cycle(road_map):
    current_distance = compute_total_distance(road_map)
    for i in range(1000):
        indx1 = random.randint(1,49)
        indx2 = random.randint(1,49)
        new_list = swap_cities(road_map, indx1, indx2)
        
        if current_distance > new_list[1]:
            road_map = new_list[0]
            current_distance = new_list[1]
        else:
            pass
    return road_map

def print_map(road_map):
    total_cost = 0
    print('===============================================================================')
    print('\t The best road_map is:\n')
    for i in range (len(road_map)-1):
        cost = math.sqrt((pow((road_map[i+1][2] - road_map[i][2]),2))
                      + (pow((road_map[i+1][3] - road_map[i][3]),2)))
        total_cost += cost
        print(road_map[i][1],'-->',road_map[i+1][1], '\tThe distance between is:',cost,'\n')
    print('\t The shortest total distance is:', total_cost)
    print('===============================================================================')

def main():
    file_name = "D:\\Courses&Assignments\\cit590\\homework\\HW4\\city-data.txt"
    road_map = read_cities(file_name)
    print_cities(road_map)
    print('Total distances of each of the three best cycles are: \n')

    dis = []
    mp = []
    for i in range(3):
        rp = road_map[:50]
        random.shuffle(rp)
        rp.append(rp[0])
        current_road_map = find_best_cycle(rp)
        total_distance = compute_total_distance(current_road_map)
        print(total_distance,'\n')

        dis.append(total_distance)
        mp.append(current_road_map)

    shortest_distance = min(dis)
    best_road_map = mp[dis.index(shortest_distance)]
    print_map(best_road_map)


main()  
        
        
    
        
        
        
        
        
        
    
    
        
    
    



        
        

        
    
        
        
    
        
        
        
        

