# Name: Mingxuan Sun
# Penn ID: 55323554

import unittest
from cities import *

class TestCities(unittest.TestCase):

    def test_computer_total_distance(self):
        self.assertEqual(computer_total_distance(read_cities('f:\\Master\Courses\CIT590\HW4\city-data.txt')), 1060.1714633538202)

    def test_swap_cities(self):
        self.assertEqual(swap_cities(read_cities('f:\\Master\Courses\CIT590\HW4\city-data.txt'), 1, 49)[0][1],
                        ('Wyoming', 'Cheyenne', 41.145548, -104.802042))
        self.assertEqual(swap_cities(read_cities('f:\\Master\Courses\CIT590\HW4\city-data.txt'), 1, 49)[0][49],
                        ('Alaska', 'Juneau', 58.301935, -134.41974))
        self.assertEqual(swap_cities(read_cities('f:\\Master\Courses\CIT590\HW4\city-data.txt'), 1, 49)[1], 1069.3403890955703)

    def test_find_best_cycle(self):
        self.assertEqual(find_best_cycle(read_cities('f:\\Master\Courses\CIT590\HW4\city-data.txt'))[1], 1060.1714633538202)

if __name__ == "__main__":
    unittest.main()
