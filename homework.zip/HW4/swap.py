#Student name: Zhefu Peng
#Student Penn ID: 29419150


#The path and the name of the certain file
file_name = "D:\\Courses&Assignments\\cit590\\homework\\HW4\\city-data.txt"
index1 = 0
index2 = 0

import random
import math

def read_cities(file_name):
    f = open(file_name)
    lines = f.readlines()
    road_map = []
    for line in lines:
        #Clear the table
        line_change = line.split('\t')
        #Make string be the float.
        line_change[2] = float(line_change[2])
        line_change[3] = float(line_change[3])
        #line_change[3] = round(line_change[2],2)
        road_map.append(tuple(line_change))
    road_map.append(road_map[0])
    f.close()    
    return road_map
    

def print_cities(road_map):
    #Since we do not need to test, we need not to print a list.
    #Just use the print function.
    for i in range(0,50):
        print('State: {0},  City: {1}, Approxiamtely Lattitude:{2},\
              Approximately Altitude:{3}\n'.format(road_map[i][0],road_map[i][1],\
                                                   round(road_map[i][2],2),\
                                                 round(road_map[i][3],2)))

    print("*******************************************************************")
              


def compute_total_distance(road_map):
    #Initialization
    total_distance = 0
    Lat1 = 0
    Lat2 = 0
    Alt1 = 0
    Alt2 = 0
    #Calculating the total distance
    for i in range(0,len(road_map)-1):
        Lat1 = road_map[i][2]
        Lat2 = road_map[i+1][2]
        Alt1 = road_map[i][3]
        Alt2 = road_map[i+1][3]
        Lat_change = abs(Lat1 - Lat2)
        Alt_change = abs(Alt1 - Alt2)
        total_distance += math.sqrt(Lat_change**2 + Alt_change**2)
        
    return total_distance


def swap_cities(road_map, index1, index2):
    new_road_map = road_map
    saving = []
    #Judge the index number whether they are same.
    if index1 != index2:
        saving = new_road_map[index1]
        new_road_map[index1] = new_road_map[index2]
        new_road_map[index2] = saving
        
    else:
        pass 
    new_total_distance = compute_total_distance(new_road_map)
    return(new_road_map, new_total_distance)

    
def find_best_cycle(road_map):
    current_distance = compute_total_distance(road_map)
    shortest_roadmap = road_map
    for i in range(0,1000):
        
        #Using the seed function to help us to test.
        #When we do not need to run the test and run the program, just note it.
        #random.seed(1)
        
        index1 = random.randint(1, 49)
        index1 = 2
        
        #random.seed(2)
        index2 = random.randint(1, 49)
        index2 = 22
        a= swap_cities(road_map, index1, index2)
        
        if a[1] < current_distance:
            current_distance = a[1]
            shortest_roadmap = a[0]
        else:
            pass
        
    #return a list which includes the road map & least distance
    #help me need not to calculate the least distance again
    return [shortest_roadmap, current_distance]


def print_map(road_map):
    total_dis = 0
    for i in range (0, len(road_map)-1):
        dis_x = abs(road_map[i][2] - road_map[i+1][2])
        dis_y = abs(road_map[i][3] - road_map[i+1][3])
        dis_total = math.sqrt((dis_x ** 2) + (dis_y ** 2))
        print('From',road_map[i][1], '>>>>>>>>>>>', road_map[i+1][1], '\nThe distance is:', dis_total, '\n')
        total_dis += dis_total
    print("**********************************************************************")
    print('The shortest total distance is:', total_dis)
    print("=====================================================================")
    

def main():
   
    road_map = read_cities("D:\\Courses&Assignments\\cit590\\homework\\HW4\\city-data.txt")
    #print_cities(road_map)
    print('本身第三个城市：',road_map[2])
    print(compute_total_distance(road_map))
    a = swap_cities(road_map, 2, 22)
    road_map = a[0]
    print('交换3和23以后的距离：',a[1])
    b = find_best_cycle(road_map)
    print('进行判断以后应该有的距离：',b[1])
    print('进行判断以后得到的第三个城市',b[0][2])
    
    
    
    #print('new map:',b[0][2])
    #print('new_distance:',b[1])
    
    #find_best_cycle(road_map)

main()
    
