


file_name = "D:\\Courses&Assignments\\cit590\\homework\\HW5\\resume.txt"
#Read the text file
def read_resume(file_name):
    f = open(file_name)
    lines = f.readlines()
    resume = []
    
    for line in lines:
        line_change = line.strip()
        resume.append(line_change)
        
    f.close()    
    return resume


#Detecting name
def detect_name(resume):
    if resume[0][5].isupper():
        name = resume[0][5:]
        return name
    else:
        raise ValueError('The name is not proper!')


#Detecting email
def detect_email(resume):
    #start finding the line which includes email
    lines = len(resume)
    for i in range(0,lines):
        if '@' in resume[i]:
            num = resume[i].index('@') #Remember the location that have '@' to test
            if resume[i][-4:] == '.com' or resume[i][-4:] == '.edu':
                if resume[i][num+1].islower():
                    return resume[i]

#Detecting courses
def detect_courses(resume):
    #start finding the line which includes course
    lines = len(resume)
    for i in range(0, lines):
        #Extract the course line
        if 'Courses' in resume[i]:
            course_line = i
            
    #Delete the word 'Courses'
    courses = resume[course_line].strip('Courses')
    
    #Delete all random punctuation before the first course
    length = len(courses)
    
    for j in range(0,length): #Find where is the start point of the courses's name
        if courses[j].isalpha():
            break
    return(courses[j:])


#Detecting projects
def detect_projects(resume):
    projects = []
    #start finding the line which includes projects
    lines = len(resume)
    for i in range(0, lines):
        if 'Projects' in resume[i]:
            projects_line = i

    #Finding the end line with '-------------'
    for j in range(0, lines):
        if '----------' in resume[j]:
            end_line = j
            
    #Get the list of projects who may contain the blank
    project = resume[projects_line + 1:end_line]
    num = len(project)
    
    #Start deleting/ignoring the blank
    for k in range(0,num):
        if project[k] != '':
            projects.append(project[k])
    return projects



#Detecting education
def detect_education(resume):
    education = []
    lines = len(resume)
    for i in range(0,lines):
        if 'University' in resume[i] or 'university' in resume[i]:
            if 'Bachelor' in resume[i] or 'bachelor' in resume[i]  or 'Master' in resume[i] or 'master' in resume[i] or 'PHD' in resume[i]:
                #Extract the line which contained degree
                education.append(resume[i])

    return education
                





def main():
    resume = read_resume(file_name)
    #print(resume)
    name = detect_name(resume)
    print(name)
    email = detect_email(resume)
    print(email)
    courses = detect_courses(resume)
    #print(courses)
    projects = detect_projects(resume)
    #print(projects[0],'\n',projects[1])
    education = detect_education(resume)

    
if __name__ == '__main__':
    main()
    
