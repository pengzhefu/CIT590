#This part is written by Zhefu PENG
#Penn ID:29419150

import unittest
from resume import *

#Create a new list of resume to test 
resume = ['I.M. Name',          
          'name@seas.upenn.edu', 
          'Projects',
          'Superman',
          '',
          'Ironman',
          '------------------------------',
          '',
          'Courses :/ …- CIT 590, ESE 507, ESE 504',
           '',
          'University of Pennsylvania, Master of Science in Scientific Computing',
          'University of Illinois, Bachelor of Science in Mathematics',
          '']
class TestResume(unittest.TestCase):

    def test_detect_name(self):
        
        self.assertEqual(detect_name(resume),'Name')

        
        #Creating a list which may contain some name error 
        resume1 = ['I.M. name',          
          'name@seas.upenn.edu', 
          'Projects',
          'Superman',
          '',
          'Ironman',
          '------------------------------',
          '',
          'Courses :/ …- CIT 590, ESE 507, ESE 504',
           '',
          'University of Pennsylvania, Master of Science in Scientific Computing',
          'University of Illinois, Bachelor of Science in Mathematics',
          '']
        self.assertRaises(ValueError, detect_name, resume1)
        
        
       
    def test_detect_email(self):
        
        self.assertEqual(detect_email(resume),'name@seas.upenn.edu')
        
       
    def test_detect_courses(self):
        
        self.assertEqual(detect_courses(resume),'CIT 590, ESE 507, ESE 504')
        

        
    def test_detect_projects(self):
        
        self.assertEqual(detect_projects(resume),['Superman', 'Ironman'])
        

    def test_detect_education(self):
        
        self.assertEqual(detect_education(resume),['University of Pennsylvania, Master of Science in Scientific Computing',
          'University of Illinois, Bachelor of Science in Mathematics'])

        

if __name__ == '__main__':
    unittest.main()


