'''
Name:Zhefu Peng
Penn ID: 29419150
Resources: Book named <<Byte of Python>>
           And some ideas from the recitation's work: Cashier 

'''

condition = True

while condition:
    #Show the current situation
    print("The current Altitude is 1000 m.")
    print("The current fuel is 1000 L.")
    print("The current speed is 0.")
    print("Are you ready to play?")
    #Initial
    altitude = 1000.0
    velocity = 0.0
    nfuel = 1000.0
    v1 = velocity
    h = altitude
    t = 0

    while altitude > 0:
        fuel = float(input("How much fuel you are going to use:"))

        #Predict any cheating from player
        if fuel > nfuel:
            fuel = nfuel
            print("\nWARNING! There is no fuel left!\n")
        
        elif fuel < 0:
            fuel = 0

        #Perform the calculations
        nfuel = nfuel - fuel
        v2 = v1 + 1.6 - 0.15 * fuel
        altitude = altitude - v2
        v1 = v2
        t = t + 1
        print("Now the speed is:",v1)
        print("Now the fuel left:",nfuel)
        print("Now the altitude is:",altitude)
        continue
    
    #Show the result
    else:
        if v1 < 10:
            print("Congratulations! You won the game!")
            print("The  Velocity is:",v1,"m/s")
            print("You still have",nfuel,"L fuel")
            print("The time you used is:", t,"s")
        else:
            print("Ouch! You lost!")
    print("Thank you for your playing!")

    again = True
    #Whether play or not
    while again:
        play = input("Have Fun huh? How about one more time?(y/n)")
        if play == 'y' or play == 'Y':
            again = False
            condition = True
                    
        elif play == 'n' or play == 'N':
            again = False
            condition = False
            
        else:
            print("What did you type? Please enter again!")
            continue
print("Bye Bye!")
    
    

    
