How to run my code: 
There are two ways to run my code: First, just open the IDLE, then open the code file, press F5 or Fn + F5 from the keyboard. When the screen shows "How much fuel will you burn", then input any number you want, the code will run and the game will begin. Second, press 'Win' + R, type in "cmd" to run cmd, then find where code saves. Just type "py lunar.py". When the screen shows "How much fuel will you burn", then input any number you want, the code will run and the game will begin.



List of input that leads to "win": 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 50 100 50 0 100 0 0 0 0 40 0 0 10 0



List of input that leads to "lose": 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0